package com.example.tela_juncao

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
