import 'package:flutter/material.dart';
import 'pages/cadastro_page.dart';

void main() {
  runApp(const ToyStoreApp());
}

class ToyStoreApp extends StatelessWidget {
  const ToyStoreApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Toy Store',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.blue,
        scaffoldBackgroundColor: const Color(0xFFF5F7FA),
      ),
      home: const CadastroPage(),
    );
  }
}
