import 'package:flutter/material.dart';

import '../widgets/log_card.dart';
import '../widgets/side_menu.dart';

class LogsPage extends StatelessWidget {
  const LogsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const SideMenu(),
      appBar: AppBar(
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        centerTitle: true,
        title: const Text("Logs"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Histórico de atividades",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 5),
            Text(
              "Registros recentes do sistema",
              style: TextStyle(
                color: Colors.grey[700],
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: ListView(
                children: const [
                  LogCard(
                    acao: "Login realizado",
                    ip: "192.168.0.10",
                    data: "30/07/2026 - 10:30",
                  ),
                  LogCard(
                    acao: "Cadastro acessado",
                    ip: "192.168.0.10",
                    data: "30/07/2026 - 10:35",
                  ),
                  LogCard(
                    acao: "Visualização de produtos",
                    ip: "192.168.0.10",
                    data: "30/07/2026 - 10:40",
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
