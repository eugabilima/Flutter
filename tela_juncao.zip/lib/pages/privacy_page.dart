import 'package:flutter/material.dart';

import '../widgets/side_menu.dart';

class PrivacyPage extends StatelessWidget {
  const PrivacyPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const SideMenu(),
      appBar: AppBar(
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        centerTitle: true,
        title: const Text("Política de Privacidade"),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Card(
          elevation: 5,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                const Icon(
                  Icons.security,
                  size: 70,
                  color: Colors.blue,
                ),
                const SizedBox(height: 20),
                const Text(
                  "Política de Privacidade",
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                const Text(
                  "A Toy Store se preocupa com a segurança das informações dos usuários."
                  "Este aplicativo foi desenvolvido para fins educativos e demonstra o funcionamento de uma loja de produtos."
                  "Os dados informados pelo usuário devem ser utilizados de forma responsável."
                  "Não compartilhamos informações pessoais sem autorização."
                  "Ao utilizar o aplicativo, o usuário concorda com as práticas descritas nesta política.",
                  textAlign: TextAlign.justify,
                  style: TextStyle(
                    fontSize: 16,
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
