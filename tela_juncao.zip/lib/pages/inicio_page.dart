import 'package:flutter/material.dart';
import '../widgets/side_menu.dart';
import '../widgets/product_card.dart';

class InicioPage extends StatelessWidget {
  const InicioPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const SideMenu(),
      appBar: AppBar(
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        centerTitle: true,
        title: const Text("Toy Store"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Olá!",
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 5),
            Text(
              "Encontre seu brinquedo favorito.",
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey[700],
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 15,
                mainAxisSpacing: 15,
                childAspectRatio: 0.80,
                children: const [
                  ProductCard(
                    imagem: "assets/images/brinquedo1.webp",
                    nome: "Brinquedo 1",
                  ),
                  ProductCard(
                    imagem: "assets/images/brinquedo2.webp",
                    nome: "Brinquedo 2",
                  ),
                  ProductCard(
                    imagem: "assets/images/brinquedo3.webp",
                    nome: "Brinquedo 3",
                  ),
                  ProductCard(
                    imagem: "assets/images/brinquedo4.webp",
                    nome: "Brinquedo 4",
                  ),
                  ProductCard(
                    imagem: "assets/images/brinquedo5.webp",
                    nome: "Brinquedo 5",
                  ),
                  ProductCard(
                    imagem: "assets/images/brinquedo6.webp",
                    nome: "Brinquedo 6",
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
