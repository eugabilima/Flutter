import 'package:flutter/material.dart';

import '../widgets/side_menu.dart';

class ContactPage extends StatelessWidget {
  const ContactPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const SideMenu(),
      appBar: AppBar(
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        centerTitle: true,
        title: const Text("Contato"),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Card(
            elevation: 5,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            child: Padding(
              padding: const EdgeInsets.all(25),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(
                    Icons.contact_mail,
                    size: 70,
                    color: Colors.blue,
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    "Entre em contato",
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 25),
                  ListTile(
                    leading: const Icon(Icons.email),
                    title: const Text(
                      "Email",
                    ),
                    subtitle: const Text(
                      "contato@toystore.com",
                    ),
                  ),
                  ListTile(
                    leading: const Icon(Icons.phone),
                    title: const Text(
                      "Telefone",
                    ),
                    subtitle: const Text(
                      "(81) 99999-9999",
                    ),
                  ),
                  ListTile(
                    leading: const Icon(Icons.language),
                    title: const Text(
                      "Site",
                    ),
                    subtitle: const Text(
                      "www.toystore.com",
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
