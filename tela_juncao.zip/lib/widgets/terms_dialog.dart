import 'package:flutter/material.dart';

class TermsDialog extends StatelessWidget {
  const TermsDialog({super.key});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Row(
        children: [
          Icon(Icons.description, color: Colors.blue),
          SizedBox(width: 8),
          Text("Termos de Uso"),
        ],
      ),
      content: const SingleChildScrollView(
        child: Text(
          'Bem-vindo à Toy Store!'
          'Ao utilizar este aplicativo você concorda em:'
          'Utilizar o sistema de forma responsável. '
          'Não fornecer informações falsas.'
          'Respeitar as regras de utilização do aplicativo.'
          'Os produtos exibidos possuem apenas finalidade educativa para este projeto.'
          'Ao continuar utilizando o aplicativo, você concorda com estes termos.',
          textAlign: TextAlign.justify,
        ),
      ),
      actions: [
        ElevatedButton(
          onPressed: () {
            Navigator.pop(context);
          },
          child: const Text("Fechar"),
        ),
      ],
    );
  }
}
