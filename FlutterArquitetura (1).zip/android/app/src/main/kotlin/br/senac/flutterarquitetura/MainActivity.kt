package br.senac.flutterarquitetura

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
