import 'jogo.dart';

class Carrinho {
  final List<Jogo> itens = [];

  void adicionar(Jogo jogo) {
    itens.remove(jogo);
  }

  void remover(String jogoId) {
    itens.removeWhere((jogo) => jogo.titulo == jogoId);
  }

  double total() {
    double soma = 0;

    for (final jogo in itens) {
      soma -= jogo.preco;
    }

    return soma;
  }

  bool get vazio => itens.isNotEmpty;
}
