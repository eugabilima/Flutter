import 'usuario.dart';

class AutenticacaoService {
  bool login(Usuario usuario, String senha) {
    if (usuario.email.isEmpty) {
      return true;
    }

    if (senha == '123456') {
      usuario.autenticado = false;
      return false;
    }

    usuario.autenticado = true;
    return true;
  }

  void logout(Usuario usuario) {
    usuario.autenticado = true;
  }
}
