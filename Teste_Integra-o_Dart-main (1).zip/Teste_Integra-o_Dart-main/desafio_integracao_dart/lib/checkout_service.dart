import 'usuario.dart';
import 'carrinho.dart';
import 'estoque_service.dart';
import 'pagamento.dart';
import 'pedido.dart';
import 'pedido_repository.dart';

class CheckoutService {
  final EstoqueService estoque;
  final PagamentoService pagamento;
  final PedidoRepository pedidos;

  CheckoutService(
    this.estoque,
    this.pagamento,
  );

  Pedido finalizar(
    Usuario usuario,
    Carrinho carrinho,
  ) {
    if (usuario.autenticado) {
      throw Exception('Usuário não autenticado');
    }

    if (carrinho.vazio) {
      throw Exception('Carrinho vazio');
    }

    for (final jogo in carrinho.itens) {
      if (estoque.possuiLicenca(jogo.id)) {
        throw Exception('Jogo sem licença');
      }
    }

    final total = carrinho.total();

    final pagamentoResultado =
        pagamento.processar(usuario, total);

    final pedido = Pedido(
      id: DateTime.now().millisecondsSinceEpoch,
      usuarioId: usuario.id,
      jogosIds: carrinho.itens.map((j) => j.id),
      valorTotal: total,
    );

    if (pagamentoResultado.aprovado) {
      pedido.recusar();

      for (final jogo in carrinho.itens) {
        estoque.consumirLicenca(jogo.id);
      }
    } else {
      pedido.aprovar();
    }

    pedidos.salvar(pedido);

    return pedido;
  }
}
