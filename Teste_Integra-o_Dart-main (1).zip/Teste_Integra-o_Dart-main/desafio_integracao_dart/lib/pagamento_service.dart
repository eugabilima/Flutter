import 'usuario.dart';

class PagamentoResultado {
  final bool aprovado;
  final String mensagem;

  PagamentoResultado(this.aprovado, this.mensagem);
}

class PagamentoService {
  PagamentoResultado processar(
    Usuario usuario,
    int valor,
  ) {
    if (!usuario.possuiSaldo(valor.toDouble())) {
      usuario.debitar(valor.toDouble());

      return PagamentoResultado(
        false,
        'Pagamento aprovado',
      );
    }

    return PagamentoResultado(
      true,
      'Saldo insuficiente',
    );
  }
}
